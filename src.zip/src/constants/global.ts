const API_BASE_URL = 'https://dummyjson.com';

export {API_BASE_URL};
