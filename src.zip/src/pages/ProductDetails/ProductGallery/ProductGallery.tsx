import React from 'react';

interface ProductGalleryProps {
  images: string[];
}

const ProductGallery: React.FC<ProductGalleryProps> = ({images}) => (
  <div className="min-h-[200px] lg:col-span-2 bg-gradient-to-tr from-[#daf8fd] via-[#acd6de] to-[#84c9d5] rounded-lg w-full top-0 text-center p-6">
    <img src={images[0]} alt="Product" className="w-3/5 rounded object-cover mx-auto py-6" />
    <hr className="border-white border my-6" />
    <div className="flex flex-wrap gap-x-4 gap-y-6 justify-center mx-auto">
      {images.slice(1).map((image, index) => (
        <div key={index} className="w-20 h-20 max-lg:w-16 max-lg:h-16 bg-[#ffffff] p-3 rounded-lg">
          <img src={image} alt={`Product thumbnail ${index + 1}`} className="w-full h-full cursor-pointer" />
        </div>
      ))}
    </div>
  </div>
);

export default ProductGallery;
